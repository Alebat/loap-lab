import sys


def oo(fin, fout, num, den):
    with open(fin, "r") as f:
        with open(fout, "w") as fw:
            for index, line in enumerate(f):
                if index % den == num:
                    fw.write(line)


oo(sys.argv[1], sys.argv[1]+'0', 0, 3)
oo(sys.argv[1], sys.argv[1]+'1', 1, 3)
oo(sys.argv[1], sys.argv[1]+'2', 2, 3)


first_val = None
with open(sys.argv[1]+'2', "r") as f:
    with open(sys.argv[1]+'2f', "w") as fw:
        for index, line in enumerate(f):
            val = int(line.split(" ")[1].rstrip())
            if val > 0:
                if first_val is None:
                    first_val = val
                fw.write(line.split(" ")[0] + " " + str(val - first_val) + "\n")
